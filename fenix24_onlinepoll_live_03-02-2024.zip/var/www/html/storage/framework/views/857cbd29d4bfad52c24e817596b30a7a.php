<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <div class="col-md-12">
         <div class="card mb-4">
            <h5 class="card-header"><?php echo e(__('admin.change_password')); ?></h5>
            <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                  <label><?php echo e(session('success')); ?></label>
               </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
               <div class="alert alert-danger" role="alert">
                  <label><?php echo e($errors->all()[0]); ?></label>
               </div>
            <?php endif; ?>
            <hr class="my-0">
            <div class="card-body">
               <form method="POST" action="<?php echo e(route('change-password')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="mb-3 col-md-6">
                        <label for="old_password" class="form-label"><?php echo e(__('admin.old_password')); ?></label>
                        <input class="form-control" type="password" id="old_password" name="old_password" value="">
                     </div>
                  </div>
                  <div class="row">
                     <div class="mb-3 col-md-6">
                        <label for="new_password" class="form-label"><?php echo e(__('admin.new_password')); ?></label>
                        <input class="form-control" type="password" id="new_password" name="new_password" value="">
                     </div>
                  </div>
                  <div class="row">
                     <div class="mb-3 col-md-6">
                        <label for="confirm_password" class="form-label"><?php echo e(__('admin.re_enter_password')); ?></label>
                        <input class="form-control" type="password" id="confirm_password" name="confirm_password" value="">
                     </div>
                  </div>
                  <div class="mt-2">
                     <button type="submit" class="btn btn-primary me-2"><?php echo e(__('admin.save')); ?></button>
                  </div>
               </form>
            </div>
            <!-- /Account -->
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/change_password.blade.php ENDPATH**/ ?>