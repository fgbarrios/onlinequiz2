<?php $__env->startSection('content'); ?>
<style type="text/css">
   .status-indicator {
   width: 10px;
   height: 10px;
   border-radius: 50%;
   display: inline-block;
   margin-right: 10px;
   }
   .online {
   background-color: #239f23;
   }
   .offline {
   background-color: #ff6c6c;
   }
   .recent
   {
      margin-bottom: 5px;
      padding: 5px;
   }
   .inviteDriends{
      width: 11rem;height: auto;
   }
   @media only screen and (max-width: 800px) {
      .inviteDriends{
      width: 9rem;
      height: auto;
   }
}
   @media only screen and (max-width: 340px) {
      .inviteDriends{
      width: 9rem;
      height: auto;
   }
}
</style>
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <div class="col-lg-12 mb-4 order-0">
         <div class="">
            <div class="d-flex align-items-end row">
               <div class="col-sm-12">
                  <div class="">
                     <div class="row">
                        <div class="col-md-5 col-12 mt-3">
                           <div class="row box-shadow">
                              <div class="col-md-6 col-6" align="left">
                                 <a href="<?php echo e(route('add-activity')); ?>" class="btn btn-primary btn-icons"><img class="add-icon" src="<?php echo e(asset('admin/assets/add_icon.svg')); ?>"><?php echo e(__('admin.add_activity')); ?></a>
                              </div>
                              <div class="col-md-6 col-6" align="right">
                                 <a href="<?php echo e(route('list-activity')); ?>" class="lable_title"><?php echo e(__('admin.go_to_activities')); ?></a>
                              </div>
                           </div>
                           <div class="row box-shadow mt-4">
                        <div class="col-md-12 col-12">
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <label class="activity_lable"><?php echo e(__('admin.response_url')); ?></label>
                              </div>
                              <div class="col-md-10 col-10" align="left">
                                 <a  class="url_title" href="<?php echo e(url('/')); ?>/visit/<?php echo e(Auth::user()->username); ?>" target="_blank"><?php echo e(url('/')); ?>/visit/<?php echo e(Auth::user()->username.'...'); ?> </a>
                              </div>
                              <div class="col-md-2 col-2" align="right">
                                 <a href="<?php echo e(route('profile')); ?>" class="lable_title"><?php echo e(__('admin.edit')); ?></a>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-12"><br><br></div>
                              <div class="col-md-12">
                                 <p class="active_status"><?php echo e(__('admin.activity_status')); ?> <?php if($active_count>0): ?><span class="status-indicator online"></span> <?php else: ?> <span class="status-indicator offline"></span> <?php endif; ?> </p>
                                 <?php if($active_count>0): ?>
                                 <label><p><?php echo e(__('admin.active_status_1')); ?></p></label>
                                 <?php else: ?>
                                 <label><p><?php echo e(__('admin.active_status_2')); ?></p></label>
                                 <?php endif; ?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row box-shadow mt-4 p-0">
                        <div class="col-md-6 col-6 p-0">
                           <img src="<?php echo e(asset('admin/assets/invite_visitors.png')); ?>" class="inviteDriends"  align="Invite Visitors">
                        </div>
                        <div class="col-md-6 col-6" align="left">
                           <p class="url_title"><?php echo e(__('admin.invite_visitors')); ?></p>
                           <a href="<?php echo e(route('invite-visitors')); ?>" class="btn btn-primary w-100"><?php echo e(__('admin.get_started')); ?></a>
                        </div>
                     </div>
                        </div>
                        <div class="col-md-1 col-1"></div>
                        <div class="col-md-6 col-12 mt-3">
                           <div class="row box-shadow">
                            <div class="col-12">
                            <div class="row">
                              <div class="col-md-12 col-12">
                                 <h5 class="lable_title"><?php echo e(__('admin.recent_activity')); ?></h5>
                              </div>
                           </div>
                           <?php if(count($activity_data)>0): ?>
                           <?php $__currentLoopData = $activity_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="row recent">
                              <p class="activity_list" style="cursor:pointer;" onclick="window.open('<?php echo e(url('/')); ?>/see-graph-response/<?php echo e(app_encode($value->id)); ?>','_blank');"><i class='bx bxs-notepad' ></i> <label style="cursor:pointer;"><?php echo e($value->title); ?></label></p>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php else: ?>
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <label ><?php echo e(__('admin.no_recent_activity')); ?></label>
                              </div>
                           </div>
                           <?php endif; ?>
                            </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
let from    = 101;
let to      = 10;
let until   = 300;

function load_activity_data()
{
   // $.ajax({
   //         url: "<?php echo e(route('load-activity-data')); ?>",
   //         type: "GET",
   //         data: {'from' : from,'to' : to},
   //         beforeSend: function() {
   //         },
   //         success: function(data) {
   //             if(data.code==200)
   //             {
   //                from   = to+1;
   //                to     = to+10;
   //                if(to <=until)
   //                {
   //                   load_activity_data();
   //                }
   //                console.log("Done : "+from+" - "+to);
   //             }
   //         },
   //         error: function(e) {
   //         }
   //     });
}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>