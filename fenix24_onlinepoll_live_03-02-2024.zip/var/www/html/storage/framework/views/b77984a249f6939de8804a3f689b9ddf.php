
<?php $__env->startSection('content'); ?>
<table class="inner-body" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
   <tr>
      <td class="content-cell">
         <p><b><?php echo e(__('admin.hello')); ?> <?php echo e($mailData['data']['email']); ?></b></p>
         <br>
         <p style="white-space:pre-line;"><?php echo e($mailData['data']['message']); ?></p>
         <br>
         <p><a href="<?php echo e($mailData['data']['visit_url']); ?>" class="button button-green"><?php echo e(__('admin.visit')); ?></a></p>
      </td>
   </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.email.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/email/invite_visitors.blade.php ENDPATH**/ ?>