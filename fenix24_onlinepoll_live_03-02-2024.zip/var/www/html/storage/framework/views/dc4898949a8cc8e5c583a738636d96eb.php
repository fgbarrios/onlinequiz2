<div class="row">
<div class="col-md-5 col-12">
<img src="<?php echo e(asset('admin/assets/presentation.jpg')); ?>" style="width: 80%;height: auto;" alt="Presentation Image">
</div>
<div class="col-md-5 div-center">
<p style="margin-top:7rem"></p>
<h5><?php echo e(__('visitors.waiting_for')); ?> <?php echo e($username); ?> <?php echo e(__('visitors.presentation_begin')); ?></h5>
<p><?php echo e($username); ?> <?php echo e(__('visitors.presentation_para')); ?></p>
</div>
</div><?php /**PATH /var/www/html/resources/views/visitors/presentation.blade.php ENDPATH**/ ?>