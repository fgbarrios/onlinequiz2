<?php $__env->startSection('content'); ?>
<!-- Content -->
<style>
tbody tr {
    background-color: #F4F4F4;
}

th {
    font-weight: 400;
}
.over-flow_y {
    min-height: 10px;
    max-height: 1000px;
}
</style>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="">
        <div class="">
            <div class="row ">
                <div class="col-md-9 col-12  ">
                    <div class="box-shadow">
                        <h4 class="qust_lable"><?php if(isset($activity_data[0]->title)): ?><?php echo e($activity_data[0]->title); ?><?php endif; ?>
                        </h4>
                        <div class="row">
                            <div class="col-md-12">
                                <h4 class="qust_lable"><?php echo e(__('admin.summary')); ?></h4>
                            </div>
                            <div class="col-md-6 table-responsive">
                                <table class="table table-hover table-responsive" width="100%">
                                    <thead>
                                        <tr>
                                            <th colspan="2"><?php echo e(__('admin.response')); ?></th>
                                            <?php if(isset($activity_data[0]->is_had_score)): ?>
                                            <?php if($activity_data[0]->is_had_score==1): ?>
                                            <th><?php echo e(__('admin.score')); ?></th>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <th align="center"><?php echo e(__('admin.count')); ?></th>
                                            <?php if(isset($activity_data[0]->is_had_score)): ?>
                                            <?php if($activity_data[0]->is_had_score==1): ?>
                                            <th><?php echo e(__('admin.total_score')); ?></th>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $total_count = 0;$total_score = 0;$total_final_score = 0; ?>
                                        <?php $__currentLoopData = $option_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $is_used = 0; ?>
                                            <?php $__currentLoopData = $value['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <?php if($is_used==0): ?>
                                                    <td rowspan="<?php echo e(count($value['options'])); ?>" style="border-right: 1px solid lightgray;"><?php echo e($value['question']); ?></td>
                                                    <?php $is_used++; ?>
                                                    <?php endif; ?>
                                                   <td align="center"><?php echo e($value1['option']); ?></td>
                                                    <?php if(isset($activity_data[0]->is_had_score)): ?>
                                                    <?php if($activity_data[0]->is_had_score==1): ?>
                                                   <td align="center"><?php echo e($value1['score']); ?></td>
                                                   <?php endif; ?>
                                                   <?php endif; ?>
                                                   <td align="center"><?php echo e($value1['select_count']); ?></td>
                                                   <?php if(isset($activity_data[0]->is_had_score)): ?>
                                                    <?php if($activity_data[0]->is_had_score==1): ?>
                                                   <td align="center"><?php echo e($value1['select_count']*$value1['score']); ?></td>
                                                   <?php endif; ?>
                                                   <?php endif; ?>
                                                </tr>
                                            <?php
                                                $total_count += $value1['select_count'];
                                                $total_score += ($value1['score'])*($value1['select_count']);
                                                $total_final_score += ($value1['score'])*($value1['select_count']);
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($option_data)==0): ?>
                                        <tr>
                                            <?php if($activity_data[0]->is_had_score==1): ?>
                                            <td colspan="5"><b><?php echo e(__('admin.no_response_available')); ?></b></td>
                                            <?php else: ?>
                                            <td colspan="4"><b><?php echo e(__('admin.no_response_available')); ?></b></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <?php if($activity_data[0]->is_had_score==1): ?>
                                            <td colspan="3" align="right"><b><?php echo e(__('admin.total')); ?></b></td>
                                            <?php else: ?>
                                            <td align="right"><b><?php echo e(__('admin.total')); ?></b></td>
                                            <?php endif; ?>
                                            <?php if($activity_data[0]->is_had_score==1): ?>
                                            <td align="center"><?php echo e($total_count); ?></td>
                                            <td align="center"><?php echo e($total_final_score); ?></td>
                                            <?php else: ?>
                                            <td></td>
                                            <td align="center"><?php echo e($total_count); ?></td>
                                            <?php endif; ?>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- <div class="col-md-1"></div> -->
                            <div class="col-md-6 table-responsive">
                                <table class="table table-hover" width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('admin.how_people_responded')); ?></th>
                                            <th><?php echo e(__('admin.count')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $total_count = 0; ?>
                                        <?php $__currentLoopData = $responseTypeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value->response_from); ?></td>
                                            <td><?php echo e($value->total_select); ?></td>
                                        </tr>
                                        <?php $total_count += $value->total_select; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($responseTypeData)==0): ?>
                                        <tr>
                                            <td colspan="2" align="center"><b><?php echo e(__('admin.no_response_available')); ?></b>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td align="center"><b><?php echo e(__('admin.total')); ?></b></td>
                                            <td align="center"><b><?php echo e($total_count); ?></b></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <h4><?php echo e(__('admin.indivitual_responses')); ?></h4>
                            </div>
                            <div class="col-md-12">
                              <div class="table-responsive over-flow_y ">
                              <table class="table table-hover" width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('admin.response')); ?></th>
                                            <th><?php echo e(__('admin.via')); ?></th>
                                            <th><?php echo e(__('admin.screen_name')); ?></th>
                                            <th><?php echo e(__('admin.received_at')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $responseAllData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><label><b><?php echo e($value->question); ?></b></label><br><label><?php echo e($value->option); ?></label></td>
                                            <td><?php echo e($value->response_from); ?></td>
                                            <td><?php echo e($value->unique_name); ?></td>
                                            <td><?php echo e(app_date_format($value->updated_at)); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($responseAllData)==0): ?>
                                        <tr>
                                            <td colspan="4" align="center"><b><?php echo e(__('admin.no_response_available')); ?></b>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                              </div>
                                
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-3 col-12  ">
                    <div class="box-shadow">
                        <div class="row">
                            <div class="col-md-12" style="display:none">
                                <p onclick="toggle_response()" style="cursor:pointer;"><i class="fa fa-share-alt" aria-hidden="true"></i>
                                    <?php echo e(__('admin.share_responses')); ?></p>
                            </div>
                            <div class="col-md-12" id="toggle_response"
                                style="display:<?php if(session('success') || $errors->any()): ?><?php echo e('block'); ?><?php else: ?><?php echo e('none'); ?><?php endif; ?>;">
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php if(session('success')): ?>
                                        <div class="alert alert-success" role="alert" align="center">
                                            <label><?php echo e(session('success')); ?></label>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($errors->any()): ?>
                                        <div class="alert alert-danger" role="alert" align="center">
                                            <label><?php echo e($errors->all()[0]); ?></label>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('share-responses')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" id="id"
                                            value="<?php if(isset($activity_data[0]->id)): ?><?php echo e(app_encode($activity_data[0]->id)); ?><?php endif; ?>">
                                            <div class="col-md-12">
                                                <input type="radio" onchange="toggle_response_via()" name="response_via" id="response_via_1" value="email" checked> <?php echo e(__('admin.email')); ?> &emsp;
                                                <input type="radio" onchange="toggle_response_via()" name="response_via" id="response_via_1" value="sms"> <?php echo e(__('admin.sms')); ?>

                                            </div>
                                        <div class="col-md-12" id="email_div" style="display:none;">
                                            <textarea class="form-control" name="email" id="email" rows="5" placeholder="<?php echo e(__('admin.use_comma')); ?>" required></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <br>
                                            <button type="submit"
                                                class="btn btn-primary btn-icons"><?php echo e(__('admin.share_responses')); ?></button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-md-12"><br></div>
                            </div>
                            <div class="col-md-12">
                                <p style="cursor:pointer;"
                                    onclick="window.location.href='<?php echo e(url("/")); ?>/download-excel/<?php echo e(app_encode($activity_data[0]->id)); ?>'">
                                    <i class='bx bx-download'></i> <?php echo e(__('admin.download_spreadsheet')); ?>

                                </p>
                            </div>
                            <div class="col-md-12">
                                <p style="cursor:pointer;"
                                    onclick="window.open('<?php echo e(url("/")); ?>/print-response/<?php echo e(app_encode($activity_data[0]->id)); ?>', '_blank');">
                                    <i class='bx bx-printer'></i> <?php echo e(__('admin.print')); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function(){
    toggle_response_via();
});
function toggle_response() {
    $("#toggle_response").toggle();
}

function toggle_response_via()
{
    var type = $('input[name="response_via"]:checked').val();
    if(type=="email")
    {
        $("#email_div").show();
        $("#email").attr("required");
    }
    else
    {
        $("#email_div").hide();
        $("#email").removeAttr("required");
        $("#email").val("");
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/activity/response_multiple.blade.php ENDPATH**/ ?>