<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="<?php echo e(asset('admin/assets/')); ?>" data-template="vertical-menu-template-free">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
      <title><?php echo e(env('APP_NAME')); ?></title>
      <meta name="description" content="" />
      <META NAME="robots" CONTENT="noindex,nofollow">
      <!-- Favicon -->
      <link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/assets/img/favicon/favicon.ico')); ?>" />
      <!-- Fonts -->
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <link href="https://fonts.googleapis.com/css2?family=Akshar:wght@300;400;500;600;700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />
      <!-- Icons. Uncomment required icon fonts -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/boxicons.css')); ?>" />
      <!-- Core CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/demo.css')); ?>" />
      <!-- Vendors CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />
      <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
      <style type="text/css">
         .bg-menu-theme {
         background-color: #211c4e !important;
         color: #697a8d !important;
         }
         .bg-menu-theme .menu-link, .bg-menu-theme .menu-horizontal-prev, .bg-menu-theme .menu-horizontal-next 
         {
         color: #ffffff;
         }
         .bg-menu-theme .menu-link:hover, .bg-menu-theme .menu-horizontal-prev:hover, .bg-menu-theme .menu-horizontal-next:hover 
         {
         color: #aba3a3;
         }
         .bg-menu-theme .menu-inner > .menu-item.active > .menu-link {
         color: #ffffff !important;
         background-color: rgb(255 255 255 / 16%) !important;
         }
         .invalid-data
         {
         color: #ff5151;
         font-size: 13px;
         margin: 5px;
         font-weight: 500;
         }
      </style>
      <!-- Page CSS -->
      <!-- Helpers -->
      <script src="<?php echo e(asset('admin/assets/vendor/js/helpers.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/config.js')); ?>"></script>
   </head>
   <body>
      <!-- Layout wrapper -->
      <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
      <!-- / Menu -->
      <!-- Layout container -->
      <div class="layout-page" style="padding: 0px;">
      <!-- / Navbar -->
      <!-- Content wrapper -->
      <div class="content-wrapper ">
         <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/activity_graph.css')); ?>">
         <!-- Content -->
         <style>
            .actionBtn{
            display: flex;
            justify-content: space-around;
            margin-bottom: 17px;
            flex-wrap: wrap;
            gap: 4px;
            }
            .align-justy{
            /*height: 100%;
            flex-direction: column;
            justify-content: space-between;*/
            }
            .accordion-button {
            background-color: #f7f7ff;
            }
            label.responsechange {
            background-color: #5B5B5B;
            padding: 4px 0px;
            border-radius: 100px;
            }
            .toggle {
            background: transparent;
            }
            .toggle-active {
            background: #3d5599 !important;
            }
            .option {
            font-weight: 500;
            margin-bottom: 0px;
            line-break: normal;
            font-size: 15px;
            }
            .title-image {
            display: block;
            width: auto;
            height: auto;
            max-width: 100%;
            max-height: 30vh;
            margin: 0 auto;
            }
            .card-body {
    flex: 1 1 auto;
    padding: 0rem 1.5rem;
}
         </style>
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
         <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
               <div class="card-body">
                  <!-- <div class="row">
                     <div class="col-md-4 col-12">
                        <h5><?php echo e(__('admin.join_by_web')); ?></h5>
                        <a href="<?php echo e($url); ?>" target="_blank"><?php echo e($url); ?></a>
                     </div>
                     <div class="col-md-4 col-12">
                        <h5><?php echo e(__('admin.join_by_text')); ?></h5>
                        <p><?php echo e(__('admin.send')); ?> <?php echo e($username); ?> <?php echo e(__('admin.to')); ?> <?php echo e($phone_number); ?></p>
                     </div>
                     <div class="col-md-4 col-12" align="center">
                        <h5><?php echo e(__('admin.join_by_scanning_qr')); ?></h5>
                        <?php echo e(QrCode::size(100)->generate($url)); ?>

                     </div>
                     </div>
                     <br> -->
                  <div class="row" id="full_page_response" style="display:none;">
                     <div class="col-md-12">
                        <!-- <div class="row" align="center" id="title_code">
                           <div class="col-md-12">
                              <h4><?php if(isset($activity_data[0]->title)): ?><?php echo e($activity_data[0]->title); ?><?php endif; ?></h4>
                              <?php if(isset($activity_data[0]->title_image)): ?> <?php if($activity_data[0]->title_image): ?>
                              <a href="<?php echo e(asset('/').'/'.$activity_data[0]->title_image); ?>" target="_blank"><img src="<?php echo e(asset('/').'/'.$activity_data[0]->title_image); ?>" class="title-image"></a><?php endif; ?>
                              <?php endif; ?>
                           </div>
                           </div>
                           <br> -->
                        <div class="row">
                           <div class="col-md-12" id="graphs">
                              <div class="row all-chart" id="chartno_1" style="display:none;">
                                 <table class="table" width="100%" id="graph_1_body">
                                 </table>
                              </div>
                              <div class="row all-chart" id="chartno_2" style="display:none;">
                                 <div class="custom-container">
                                    <table class="custom-table" align="center" id="graph_2_body">
                                    </table>
                                 </div>
                              </div>
                              <div class="row mx-auto all-chart" id="chartno_3" style="display:none;" align="center">
                                 <div id="donutchart" style="width: 100%; height: 100%;"></div>
                              </div>
                           </div>
                           <div class="col-md-12" id="instructions"  style="display:none;">
                              <div class="row mx-auto">
                                 <div class="col-md-12 col-12">
                                    <h4><?php if(isset($activity_data[0]->title)): ?><?php echo e($activity_data[0]->title); ?><?php endif; ?></h4>
                                 </div>
                                 <div class="col-md-12 col-12">
                                    <table class="table mt-3" width="100%">
                                       <tbody>
                                          <?php $__currentLoopData = $option_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr class="table-bar">
                                             <?php if(isset($activity_data[0]->is_had_score)): ?>
                                             <?php if($activity_data[0]->is_had_score==1): ?>
                                             <td width="5%" class="pointer">
                                                <div class="box">0</div>
                                             </td>
                                             <?php endif; ?>
                                             <?php endif; ?>
                                             <td width="95%" class="pointer"><?php if($value->option_image!=""): ?><img src="<?php echo e(asset($value->option_image)); ?>" alt="Option Image" class="option-image"><?php else: ?><label class="options"><?php echo e($value->option); ?></label><?php endif; ?></td>
                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row" id="full_page_empty" style="display:none;">
                     <center>
                        <h4><?php echo e(__('admin.active_status_2')); ?></h4>
                     </center>
                  </div>
                  <div class="content-backdrop fade"></div>
               </div>
               <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
         </div>
         <!-- Overlay -->
         <div class="layout-overlay layout-menu-toggle"></div>
      </div>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/jquery/jquery.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/popper/popper.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/js/bootstrap.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/js/menu.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
      <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
      <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/dashboards-analytics.js')); ?>"></script>
      <script async defer src="https://buttons.github.io/buttons.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" integrity="sha512-37T7leoNS06R80c8Ulq7cdCDU5MNQBwlYoy1TX/WUsLFC2eYNqtKlV0QjH7r8JpG/S0GUMZwebnVFLPd6SU5yg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script type="text/javascript">
         // $(function() {
         
            let resID      = "";
         let map_type   = 1;
         var socket     = new WebSocket('<?php echo e(config("app.socket_url")); ?>?user_type=admin&user_id=<?php echo e($admin_id); ?>');
         
         socket.onopen = function(e) {
         };
         
         socket.onerror = function(e) {
         };
         
         socket.onmessage = function (e) {
         var data = JSON.parse(e.data);
         if(data.type=="id")
         {
         resID = data.data;
         send_request();
         }
         else
         {
         generate_graph_result(data.data);
         }
         }
         // socket.onopen = () => send_request();
         function send_request() {
         var data = {
         type: "get-poll-result",
         resID: resID,
         adminid: '<?php echo e($admin_id); ?>',
         activity_id: <?php if(isset($activity_data[0]->id)): ?>'<?php echo e(app_encode($activity_data[0]->id)); ?>'<?php endif; ?>,
         };
         socket.send(JSON.stringify(data));
         }
            
            function generate_graph_result(data) 
            {
               if(data.option_data.length==0)
               {
                  $("#full_page_response").hide();
                  $("#full_page_empty").show();
               }
               else
               {
                  $("#full_page_response").show();
                  $("#full_page_empty").hide();
               }
               var graph_1 = '';
               var graph_2 = '';
               var graph_3 = '';
            
               var option_data   = data.option_data;
               var activity_data = data.activity_data;
               var total_image   = 0;
         
               // var percentageArray = calculate_percentage(activity_data.total_responses,option_data);
               graph_1  = '<table class="table" width="100%">';
               graph_2  = '<table class="custom-table" align="center"><tr>';
               
               for (var i = 0; i < option_data.length; i++) {
            
                  var array         = option_data[i];
                  var width_1       = "15%";
                  var width_2       = "95%";
                  var width_3       = "5%";
                  var img_class     = "";
                  var onclick       = "";
            
                  if(array.option_image)
                  {
                     img_class  = "option-image";
                  }
            
                  var total_responses  = 0;
                  var percentage       = 0;
            
                  if(activity_data[0].total_responses)
                  {
                     total_responses = activity_data[0].total_responses;
                  }
                  if(total_responses>0)
                  {
                     percentage = Math.round((array.select_count/total_responses)*100);
                  }

                  if(percentage<0)
                  {
                     percentage = 0;
                  }
         
                  var option_text_name = array.option;
                  if(option_text_name=="null" || option_text_name==null)
                  {
                     option_text_name = "";
                  }
                  var score = (array.score*array.select_count);
                  var score_text = "";

                  if(array.select_count<0)
                  {
                     score_text = '<br><label class="option">(Votes : 0)</label>';
                  }
                  else
                  {
                     score_text = '<br><label class="option">(Votes : '+array.select_count+')</label>';
                  }
                  
         
                  graph_1 += '<tr><td width="50%" align="left">';
         
                  graph_2 += '<td align="center"><span class="percentage">'+percentage+'%</span><div class="cl-bar-container"><div class="cl-bar cl-bar-fill" style="height: '+percentage+'%;"></div></div><label class="option" style="margin-top: 5px;">'+option_text_name+score_text+'</label><div class="imgdiv">';
            
                  if(array.option_image)
                  {
                     var url = '<?php echo e(asset("/")); ?>/'+array.option_image;
                     graph_1 += '<a href="'+url+'" target="_blank"><img src="'+url+'" class="title-image"></a>'+score_text;
                     graph_2 += '<a href="'+url+'" target="_blank"><img src="'+url+'" class="optionimage"></a>';
                     total_image++;
                  }
                  else
                  {
                     graph_1 += '<label class="option">'+option_text_name+score_text+'</label>';
                  }
            
                  graph_1 +='</td><td width="45%" align="right"><div class="bar-container"><div class="bar bar-fill" style="width: '+percentage+'%;"></div></div></td><td width="5%" align="left"><span class="percentage">'+percentage+'%</span></td></tr>';
                  graph_2 +='</div></td>';
               }
            
               graph_1 += '</table>';
               graph_2 += '</tr></table>';
            
               $("#graph_1_body").html(graph_1);
               $("#graph_2_body").html(graph_2);
               if(total_image==0)
               {
                  $(".imgdiv").hide();
               }
               else
               {
                  $(".imgdiv").show();
               }

               toggle_graph(map_type);
               if(activity_data[0].total_responses==0)
               {
                  $("#edit_btn").show();
               }
               else
               {
                  $("#edit_btn").hide();
               }
            } 
            
            
            function toggle_graph(type,mode="")
            {
               map_type = type;
               $(".all-chart").hide();
               $(".graph").each(function(){
                  $(this).attr("class","col-md-3 graph");
               });
               $("#graph_"+type).attr("class","col-md-3 graph graph-active");
               $("#chartno_"+type).show();
               if(type==3 && mode=="manual")
               {
                  send_request();
               }
            }
            
      </script>
   </body>
</html><?php /**PATH /var/www/html/resources/views/admin/poll_response.blade.php ENDPATH**/ ?>