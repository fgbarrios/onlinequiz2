
<?php $__env->startSection('content'); ?>
<table class="inner-body table-responsive" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
   <tr>
      <td class="content-cell">
         <h4><b><?php echo e(__('admin.hello')); ?> <?php echo e($mailData['data']['email']); ?></b></h4>
         <?php if(isset($mailData['data']['message'])): ?>
            <?php $__currentLoopData = $mailData['data']['message']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($value==""): ?>
                  <br>
               <?php else: ?>
                  <p><?php echo e($value); ?></p>
               <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
      </td>
   </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.email.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/email/share_responses.blade.php ENDPATH**/ ?>