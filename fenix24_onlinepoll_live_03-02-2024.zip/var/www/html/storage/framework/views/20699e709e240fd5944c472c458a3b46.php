<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <div class="col-md-12">
         <div class="card mb-4">
            <h5 class="card-header"><?php echo e(__('admin.profile')); ?> <?php echo e(__('admin.details')); ?></h5>
            <!-- Account -->
            <hr class="my-0">
            <div class="card-body">
               <form id="profile_form" action="<?php echo e(route('update-profile')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="mb-3 col-md-6">
                        <label for="username" class="form-label"><?php echo e(__('admin.username')); ?></label>
                        <input class="form-control" type="text" id="username" name="username" value="<?php if(isset(auth::user()->username)): ?><?php echo e(auth::user()->username); ?><?php endif; ?>" oninput="change_url();" autofocus="" placeholder="admin9988">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="polling_url" class="form-label"><?php echo e(__('admin.url')); ?></label>
                        <input class="form-control" type="text" id="polling_url" name="polling_url" value="<?php if(isset(auth::user()->polling_url)): ?><?php echo e(auth::user()->polling_url); ?><?php endif; ?>" placeholder="www.onlinepoll.com/admin9988" readonly>
                        <?php $__errorArgs = ['polling_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="email" class="form-label"><?php echo e(__('admin.email')); ?></label>
                        <input class="form-control" type="text" name="email" id="email" value="<?php if(isset(auth::user()->email)): ?><?php echo e(auth::user()->email); ?><?php endif; ?>" placeholder="admin@gmail.com">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="password" class="form-label"><?php echo e(__('admin.password')); ?></label>
                        <input class="form-control" type="password" id="password" name="password" value="">
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="first_name" class="form-label"><?php echo e(__('admin.first_name')); ?></label>
                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php if(isset(auth::user()->first_name)): ?><?php echo e(auth::user()->first_name); ?><?php endif; ?>">
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="last_name" class="form-label"><?php echo e(__('admin.last_name')); ?></label>
                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php if(isset(auth::user()->last_name)): ?><?php echo e(auth::user()->last_name); ?><?php endif; ?>">
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label class="form-label" for="phone_number"><?php echo e(__('admin.phone_number')); ?></label>
                        <div class="group">
                           <span class="input-cuntery">(+1)</span>
                           <input type="number" id="phone_number" name="phone_number" class="form-control country_input" value="<?php if(isset(auth::user()->phone_number)): ?><?php echo e(auth::user()->phone_number); ?><?php endif; ?>">
                           <input type="hidden" name="phone_code" value="1">
                        </div>
                        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="mb-3 col-md-6">
                        <label for="time_zone" class="form-label"><?php echo e(__('admin.time_zone')); ?></label>
                        <select id="time_zone" name="time_zone" class="select2 form-select">
                           <option value=""><?php echo e(__('admin.select_time_zone')); ?></option>
                           <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($value->id); ?>" <?php if(isset(auth::user()->time_zone)): ?> <?php if(auth::user()->time_zone==$value->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($value->zone_text); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['time_zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <label class="invalid-data"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                  </div>
                  <div class="mt-2">
                     <button type="submit" class="btn btn-primary me-2"><?php echo e(__('admin.update')); ?></button>
                  </div>
               </form>
            </div>
            <!-- /Account -->
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
   function change_url()
   {
      var username   = $("#username").val();
      var base_url   = '<?php echo e(url("/")); ?>';
      var final_url  = base_url+'/visit/'+username;
      $("#polling_url").val(final_url);
   }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/profile.blade.php ENDPATH**/ ?>