<?php $__env->startSection('content'); ?>
<style type="text/css">
</style>
<!-- Content -->
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <div class="col-md-12">
         <div class="card mb-4">
            <h5 class="card-header"><?php echo e(__('admin.general_settings')); ?> <?php echo e(__('admin.details')); ?></h5>
            <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
               <label><?php echo e(session('success')); ?></label>
            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
               <label><?php echo e($errors->all()[0]); ?></label>
            </div>
            <?php endif; ?>
            <!-- Account -->
            <hr class="my-0">
            <div class="card-body">
               <form id="general_form" action="<?php echo e(route('save-general-settings')); ?>" method="POST" enctype="multipart/form-data" files='true'>
                  <?php echo csrf_field(); ?>
                  <div class="row">
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_mailer" class="form-label"><?php echo e(__('admin.smtp_mailer')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="smtp_mailer" name="smtp_mailer" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_mailer); ?><?php endif; ?>" <?php echo e(__('admin.smtp_mailer')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_mailer_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_host" class="form-label"><?php echo e(__('admin.smtp_host')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="smtp_host" name="smtp_host" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_host); ?><?php endif; ?>" <?php echo e(__('admin.smtp_host')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_host_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_port" class="form-label"><?php echo e(__('admin.smtp_port')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="number" id="smtp_port" name="smtp_port" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_port); ?><?php endif; ?>" <?php echo e(__('admin.smtp_port')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_username_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_username" class="form-label"><?php echo e(__('admin.smtp_username')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="smtp_username" name="smtp_username" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_username); ?><?php endif; ?>" <?php echo e(__('admin.smtp_username')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_username_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_password" class="form-label"><?php echo e(__('admin.smtp_password')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="smtp_password" name="smtp_password" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_password); ?><?php endif; ?>" <?php echo e(__('admin.smtp_password')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_password_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="smtp_encryption" class="form-label"><?php echo e(__('admin.smtp_encryption')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="smtp_encryption" name="smtp_encryption" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->smtp_encryption); ?><?php endif; ?>" <?php echo e(__('admin.smtp_encryption')); ?>">
                        </div>
                        <label class="invalid-data" id="smtp_encryption_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="twilio_secret_key" class="form-label"><?php echo e(__('admin.twilio_secret_key')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="twilio_secret_key" name="twilio_secret_key" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->twilio_secret_key); ?><?php endif; ?>" <?php echo e(__('admin.twilio_secret_key')); ?>">
                        </div>
                        <label class="invalid-data" id="twilio_secret_key_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label for="twilio_token" class="form-label"><?php echo e(__('admin.twilio_token')); ?></label>
                        <div class="input-group">
                           <input class="form-control" type="text" id="twilio_token" name="twilio_token" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->twilio_token); ?><?php endif; ?>" <?php echo e(__('admin.twilio_token')); ?>">
                        </div>
                        <label class="invalid-data" id="twilio_token_error" style="display:none;"></label>
                     </div>
                     <div class="mb-3 col-md-6 col-12">
                        <label class="form-label" for="twilio_from_number"><?php echo e(__('admin.twilio_from_number')); ?></label>
                        <div class="group">
                           <span class="input-cuntery">(+1)</span>
                           <input type="number" id="twilio_from_number" name="twilio_from_number" class="form-control country_input" value="<?php if(isset($edit_data)): ?><?php echo e($edit_data->twilio_from_number); ?><?php endif; ?>">
                           <input type="hidden" name="twilio_from_code" id="twilio_from_code" value="1">
                        </div>
                        <label class="invalid-data" id="twilio_from_number_error" style="display:none;"></label>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6 col-12">
                        <button class="btn btn-primary" type="submit"><?php echo e(__('admin.save')); ?></button>
                     </div>
                  </div>
                  <input type="hidden" name="id" id="id" value="<?php if(isset($edit_data->id)): ?><?php echo e($edit_data->id); ?><?php else: ?><?php echo e('0'); ?><?php endif; ?>">
               </form>
            </div>
            <!-- /Account -->
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/settings/general_settings.blade.php ENDPATH**/ ?>