<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="<?php echo e(asset('admin/assets/')); ?>" data-template="vertical-menu-template-free">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
      <title><?php echo e(env('APP_NAME')); ?></title>
      <meta name="description" content="" />
      <META NAME="robots" CONTENT="noindex,nofollow">
      <!-- Favicon -->
      <link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/assets/img/favicon/favicon.ico')); ?>" />
      <!-- Fonts -->
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <link href="https://fonts.googleapis.com/css2?family=Akshar:wght@300;400;500;600;700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />
      <!-- Icons. Uncomment required icon fonts -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/fonts/boxicons.css')); ?>" />
      <!-- Core CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/demo.css')); ?>" />
      <!-- Vendors CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />
      <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
      <style type="text/css">
         .bg-menu-theme {
         background-color: #211c4e !important;
         color: #697a8d !important;
         }
         .bg-menu-theme .menu-link, .bg-menu-theme .menu-horizontal-prev, .bg-menu-theme .menu-horizontal-next 
         {
         color: #ffffff;
         }
         .bg-menu-theme .menu-link:hover, .bg-menu-theme .menu-horizontal-prev:hover, .bg-menu-theme .menu-horizontal-next:hover 
         {
         color: #aba3a3;
         }
         .bg-menu-theme .menu-inner > .menu-item.active > .menu-link {
         color: #ffffff !important;
         background-color: rgb(255 255 255 / 16%) !important;
         }
         .invalid-data
         {
         color: #ff5151;
         font-size: 13px;
         margin: 5px;
         font-weight: 500;
         }
      </style>
      <!-- Page CSS -->
      <!-- Helpers -->
      <script src="<?php echo e(asset('admin/assets/vendor/js/helpers.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/config.js')); ?>"></script>
   </head>
   <body>
      <!-- Layout wrapper -->
      <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
      <!-- / Menu -->
      <!-- Layout container -->
      <div class="layout-page" style="padding: 0px;">
      <!-- / Navbar -->
      <!-- Content wrapper -->
      <div class="content-wrapper ">
         <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/activity_graph.css')); ?>">
         <!-- Content -->
         <style>
            .actionBtn{
            display: flex;
            justify-content: space-around;
            margin-bottom: 17px;
            flex-wrap: wrap;
            gap: 4px;
            }
            .align-justy{
            /*height: 100%;
            flex-direction: column;
            justify-content: space-between;*/
            }
            .accordion-button {
            background-color: #f7f7ff;
            }
            label.responsechange {
            background-color: #5B5B5B;
            padding: 4px 0px;
            border-radius: 100px;
            }
            .toggle {
            background: transparent;
            }
            .toggle-active {
            background: #3d5599 !important;
            }
            .option {
            font-weight: 500;
            margin-bottom: 0px;
            line-break: normal;
            font-size: 15px;
            }
            .title-image {
            display: block;
            width: auto;
            height: auto;
            max-width: 100%;
            max-height: 30vh;
            margin: 0 auto;
            }
            .card-body {
            flex: 1 1 auto;
            padding: 0rem 1.5rem;
            }
         </style>
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
         <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
               <div class="card-body">
                  <div class="row" id="full_page_response" style="display:none;">
                     <div class="col-md-12">
                        <div class="row">
                           <div class="col-md-12" id="graphs">
                              <div class="row all-chart" id="chartno_1" style="display:none;">
                                 <table class="table" width="100%" id="graph_1_body">
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row" id="full_page_empty" style="display:none;">
                     <center>
                        <h4><?php echo e(__('admin.active_status_2')); ?></h4>
                     </center>
                  </div>
                  <div class="content-backdrop fade"></div>
               </div>
            </div>
         </div>
         <div class="layout-overlay layout-menu-toggle"></div>
      </div>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/jquery/jquery.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/popper/popper.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/js/bootstrap.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/js/menu.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
      <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
      <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>
      <script src="<?php echo e(asset('admin/assets/js/dashboards-analytics.js')); ?>"></script>
      <script async defer src="https://buttons.github.io/buttons.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" integrity="sha512-37T7leoNS06R80c8Ulq7cdCDU5MNQBwlYoy1TX/WUsLFC2eYNqtKlV0QjH7r8JpG/S0GUMZwebnVFLPd6SU5yg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
      <script type="text/javascript">
      let resID      = "";
      let map_type   = 1;
      var socket     = new WebSocket('<?php echo e(config("app.socket_url")); ?>?user_type=admin&user_id=<?php echo e($admin_id); ?>');

      socket.onmessage = function (e) {
         var data = JSON.parse(e.data);
         if (data.type == "id") {
            resID = data.data;
            send_request();
         } else {
            generate_graph_result(data.data);
         }
      }

      function send_request() {
         var data = {
            type: "get-poll-result",
            resID: resID,
            adminid: '<?php echo e($admin_id); ?>',
            activity_id: <?php if(isset($activity_data[0]->id)): ?>'<?php echo e(app_encode($activity_data[0]->id)); ?>'<?php endif; ?>,
         };
         socket.send(JSON.stringify(data));
      }

      function generate_graph_result(data) {
         var question_array = [];
         for (var i = 0; i < data.question_array.length; i++) {
            var array = data.question_array[i];
            if (array.question_id == <?php echo e($question_id); ?>) 
            {
               question_array.push(array);
            }
         }

         if (question_array.length == 0) {
            $("#full_page_response").hide();
            $("#full_page_empty").show();
         } else {
            $("#full_page_response").show();
            $("#full_page_empty").hide();
         }
         var optionsArray     = question_array[0].options;
         var graph_1          = '';
         graph_1              += '<table class="table" width="100%" style="background: #efefef;">';
         graph_1              += '<tr>';
         graph_1              += '</tr>';
         var width_1          = "95%";
         var width_2          = "5%";
         var img_class        = "";
         var onclick          = "";
         var percentage       = 0;

         for (var j = 0; j < optionsArray.length; j++) 
         {
            var subArray         = optionsArray[j];
            var total_responses  = 0;
            if(question_array[0].select_count)
            {
               total_responses = question_array[0].select_count;
            }
            if(total_responses>0)
            {
               percentage = Math.round((subArray.select_count/total_responses)*100);
            }
            
            if(percentage<0)
            {
               percentage = 0;
            }

            var option_text_name = subArray.option;
            if(option_text_name=="null" || option_text_name==null)
            {
               option_text_name = "";
            }

            var score      = (subArray.score*subArray.select_count);
            var score_text = "";
            if(subArray.select_count<0)
            {
               score_text     = ' (Votes : 0)';
            }
            else
            {
               score_text     = ' (Votes : '+subArray.select_count+')';
            }

            graph_1        += '<tr>';

            graph_1        +='</td><td width="'+width_1+'" align="left"><label class="option">'+option_text_name+score_text+'</label><div class="bar-container"><div class="bar bar-fill" style="width: '+percentage+'%;"></div></div></td><td width="'+width_2+'" align="left"><span class="percentage">'+percentage+'%</span></td>';
            graph_1        += '</tr>';

         }
         graph_1           += '</table>';
         $("#graph_1_body").html(graph_1);
         toggle_graph(map_type);
      }

      function toggle_graph(type,mode="")
      {
         map_type = type;
         $(".all-chart").hide();
         $(".graph").each(function(){
            $(this).attr("class","col-md-3 graph");
         });
         $("#graph_"+type).attr("class","col-md-3 graph graph-active");
         $("#chartno_"+type).show();
         if(type==3 && mode=="manual")
         {
            send_request();
         }
      }
      </script>
   </body>
</html><?php /**PATH /var/www/html/resources/views/admin/poll_response_multiple.blade.php ENDPATH**/ ?>