<?php $__env->startSection('content'); ?>
<!-- Content -->
<style>
   .prasentTiltle{
      font-size: 14px;
    color: #333;
    font-weight: 600;
   }
   .skip_link{
      color:#211C4E;
   }
   .p-5 
      {
         padding: 1rem !important;
      }
   @media (max-width:768px)
   {
      .p-5 
      {
         padding: 0rem !important;
      }
   }
</style>
<div class="" style="margin-top:0px">
   <div class="rounded d-flex justify-content-center">
      <div class="col-md-5 col-sm-12 p-5">
         <div class="text-center">
            <img src="<?php echo e(asset('admin/assets/logo.svg')); ?>" alt="Logo" style="">
            <p><br></p>
            <h5 class="mt-3 welcome_title"><?php echo e(__('visitors.welcome')); ?></h5>
            <p style="margin-bottom: 0rem;"><?php echo e(__('visitors.introduce_yourself')); ?></p>
         </div>
         <?php if($errors->any()): ?>
         <br>
         <div class="alert alert-danger" role="alert" align="center">
            <label><?php echo e($errors->all()[0]); ?></label>
         </div>
         <?php endif; ?>
         <form action="<?php echo e(route('save-visitors-details')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="p-4">
               <div class="row">
                  <div class="mb-3 col-md-12">
                     <label><?php echo e(__('visitors.name')); ?></label>
                     <input type="text" name="name" id="name" class="form-control" value="">
                  </div>
                  <div class="mb-3 col-md-12">
                     <label><?php echo e(__('visitors.email')); ?></label>
                     <input type="text" name="email" id="email" class="form-control" value="">
                  </div>
                  <div class="mb-3 col-md-12">
                     <label><?php echo e(__('visitors.phone_number')); ?></label>
                     <input type="text" name="phone_number" id="phone_number" class="form-control" value="" placeholder="<?php echo e(__('visitors.with_country_code')); ?>">
                  </div>
                  <div class="mb-3 col-md-12" align="center">
                     <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('visitors.continue')); ?></button>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.visitors_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/visitors/details.blade.php ENDPATH**/ ?>