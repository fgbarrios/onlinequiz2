<?php 

return [

	"unlimited_value" => 100000000

];

?>