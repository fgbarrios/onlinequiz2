<?php 

	return [

	"dashboard" 				=> "டாஷ்போர்டு",
	"settings" 					=> "அமைப்புகள்",
	"activity_settings" 		=> "செயல்பாட்டு அமைப்புகள்",
	"general_settings" 			=> "பொது அமைப்புகள்",
	"activities" 				=> "நடவடிக்கைகள்",
	"go_to_activity" 			=> "செயல்பாட்டிற்கு செல்க",
	"add_new" 					=> "புதிதாக சேர்க்கவும்",
	"add" 						=> "கூட்டு",
	"activity" 					=> "செயல்பாடு",
	"account" 					=> "கணக்கு",
	"profile" 					=> "சுயவிவரம்",
	"change_password" 			=> "கடவுச்சொல்லை மாற்று",
	"logout" 					=> "வெளியேறு",
	"welcome" 					=> "வரவேற்பு",
	"details" 					=> "விவரங்கள்",
	"title" 					=> "தலைப்பு",
	"how_people_can_respond" 	=> "மக்கள் எவ்வாறு பதிலளிக்க முடியும்",
	"is_score_type_option" 		=> "மதிப்பெண் வகை விருப்பமா?",
	"yes" 						=> "ஆம்",
	"no" 						=> "இல்லை",
	"text" 						=> "உரை",
	"image" 					=> "படம்",
	"option" 					=> "விருப்பம்",
	"create" 					=> "உருவாக்கு",
	"add_another_activity" 		=> "மற்றொரு செயல்பாட்டைச் சேர்க்கவும்",
	"enter" 					=> "உள்ளிடவும்",

	];

?>ACTIVITES