<div class="row">
<div class="col-md-5 col-12">
<img src="{{asset('admin/assets/presentation.jpg')}}" style="width: 80%;height: auto;" alt="Presentation Image">
</div>
<div class="col-md-5 div-center">
<p style="margin-top:7rem"></p>
<h5>{{__('visitors.waiting_for')}} {{$username}} {{__('visitors.presentation_begin')}}</h5>
<p>{{$username}} {{__('visitors.presentation_para')}}</p>
</div>
</div>